-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22-Jun-2023 às 08:09
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sistemabanco`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `admin`
--

INSERT INTO `admin` (`id`, `nome`, `email`, `senha`) VALUES
(1, 'Maria', 'maria@gmail.com', '123');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastrarclientes`
--

CREATE TABLE `cadastrarclientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `data_nasc` varchar(255) NOT NULL,
  `morada` varchar(255) NOT NULL,
  `telefone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `tipo_conta` varchar(255) NOT NULL,
  `data_criacao` date NOT NULL,
  `saldo` int(255) NOT NULL,
  `n_conta` varchar(255) NOT NULL,
  `pin` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `valor_depositado` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `cadastrarclientes`
--

INSERT INTO `cadastrarclientes` (`id`, `nome`, `data_nasc`, `morada`, `telefone`, `email`, `tipo_conta`, `data_criacao`, `saldo`, `n_conta`, `pin`, `iban`, `valor_depositado`) VALUES
(3, 'Justino Soares', '30/05/2005', 'Palanca', '946671828', 'justino@gmail.com', 'Corrente', '2023-06-07', 15900, '34854618278', '0020', '123456783485461827898', 10100),
(4, 'Mário Salembe', '21/10/2004', 'Palanca', '938393388', 'mario@gmail.com', '', '2023-06-08', 21000, '14468357285', '5562', '123456781446835728586', 0),
(5, 'Ana Francisco', '05/01/2005', 'Zango', '931473227', 'anafrancisco@gmail.com', 'Corrente', '2023-06-11', 19400, '88582604511', '9842', '123456788858260451128', 0),
(6, 'Mara Muta', '22/02/2006', 'Camama', '959595959', 'maramuta@gmail.com', 'Corrente', '2023-06-11', 10400, '79772040947', '2042', '123456787977204094722', 0),
(7, 'Emanuel de Jesus', '18/01/1954', 'Camama', '9922233445', 'emanuel@gmail.com', 'Corrente', '2023-06-12', 8000, '67773185989', '3385', '123456786777318598981', 0),
(8, 'Adelina Cassova', '30/10/2020', 'Palanca', '938573412', 'adelina@gmail.com', 'Corrente', '2023-06-15', 19600, '38374848450', '7926', '123456783837484845010', 0),
(9, 'Clara de Assis', '03/03/2006', 'Nova Vida', '940926388', 'clara@gmail.com', 'Poupança', '2023-06-19', 25200, '14773388527', '4914', '123456781477338852745', NULL),
(10, 'Augusto Gonçalves', '20/10/2006', 'Kimbango', '934343434', 'augusto@gmail.com', 'Poupança', '2023-06-19', 20000, '66614819394', '8822', '123456786661481939426', NULL),
(11, 'Mário Lino Salembe', '21/10/2004', 'Palanca', '938393388', 'linomario199010@gmail.com', 'Corrente', '2023-06-19', 15000, '80746916324', '5646', '123456788074691632473', NULL),
(12, 'Augusto Gonçalves', '24/02/2006', 'Kimbango', '938697010', 'augusto@gmail.com', 'Corrente', '2023-06-20', 30800, '51960376955', '5891', '123456785196037695577', 11000),
(13, 'Francília Humba', '11/10/2006', 'Camama', '939712899', 'francila@gmail.com', 'Poupança', '2023-06-20', 29850, '92154327597', '5144', '123456789215432759732', 10000),
(14, 'Emilina Soares', '12/06/2003', 'Palanca', '933232323', 'emiliana@gmail.com', 'Corrente', '2023-06-20', 20000, '09651590074', '3176', '123456780965159007458', NULL),
(15, 'Benjamim Soares', '05/julho/2002', 'Palanca', '923341234', 'comenia@gmail.com', 'Corrente', '2023-06-21', 20000, '24563942231', '0899', '123456782456394223136', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `registro`
--

CREATE TABLE `registro` (
  `id` int(11) NOT NULL,
  `indice` varchar(255) NOT NULL,
  `data_actual` date NOT NULL,
  `valor` int(255) NOT NULL,
  `n_conta` varchar(255) DEFAULT NULL,
  `iban` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `registro`
--

INSERT INTO `registro` (`id`, `indice`, `data_actual`, `valor`, `n_conta`, `iban`) VALUES
(1, 'Débito', '2023-06-11', 7900, '34854618278', NULL),
(2, 'Débito', '2023-06-11', 7700, '34854618278', NULL),
(3, 'Débito', '2023-06-11', 300, '34854618278', NULL),
(4, 'Débito', '2023-06-12', 12000, '67773185989', NULL),
(5, 'Crédito', '2023-06-13', 100, '79772040947', NULL),
(6, 'Débito', '2023-06-13', 100, '88582604511', NULL),
(7, 'Débito', '2023-06-13', 100, '88582604511', NULL),
(8, 'Débito', '2023-06-13', 100, '88582604511', NULL),
(9, 'Débito', '2023-06-13', 100, '88582604511', NULL),
(10, 'Crédito', '2023-06-13', 100, '79772040947', NULL),
(11, 'Débito', '2023-06-13', 200, '88582604511', NULL),
(12, 'Crédito', '2023-06-13', 200, '79772040947', NULL),
(13, 'Débito', '2023-06-15', 200, '38374848450', NULL),
(14, 'Débito', '2023-06-15', 100, '34854618278', NULL),
(15, 'Crédito', '2023-06-15', 100, '34854618278', NULL),
(16, 'Débito', '2023-06-15', 200, '38374848450', NULL),
(17, 'Crédito', '2023-06-15', 200, '79772040947', NULL),
(18, 'Crédito', '2023-06-16', 10000, '34854618278', NULL),
(19, 'Débito', '2023-06-16', 100, '34854618278', NULL),
(20, 'Débito', '2023-06-16', 10000, '79772040947', NULL),
(21, 'Crédito', '2023-06-18', 100, '34854618278', NULL),
(22, 'Débito', '2023-06-19', 5000, '80746916324', NULL),
(23, 'Crédito', '2023-06-19', 5000, '34854618278', NULL),
(24, 'Crédito', '2023-06-20', 11000, '51960376955', NULL),
(25, 'Débito', '2023-06-20', 200, '51960376955', NULL),
(26, 'Crédito', '2023-06-20', 10000, '92154327597', NULL),
(27, 'Débito', '2023-06-20', 150, '92154327597', NULL),
(28, 'Débito', '2023-06-20', 100, '14773388527', NULL),
(29, 'Débito', '2023-06-20', 200, '14773388527', NULL),
(30, 'Crédito', '2023-06-20', 200, '123456783837484845010', NULL),
(31, 'Débito', '2023-06-21', 500, '34854618278', NULL),
(32, 'Crédito', '2023-06-21', 500, '123456781477338852745', NULL),
(33, 'Débito', '2023-06-21', 1000, '34854618278', NULL),
(34, 'Crédito', '2023-06-21', 1000, '14468357285', '123456781446835728586'),
(35, 'Débito', '2023-06-21', 5000, '34854618278', NULL),
(36, 'Crédito', '2023-06-21', 5000, '14773388527', '123456781477338852745');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `cadastrarclientes`
--
ALTER TABLE `cadastrarclientes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `cadastrarclientes`
--
ALTER TABLE `cadastrarclientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `registro`
--
ALTER TABLE `registro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
